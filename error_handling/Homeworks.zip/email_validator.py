class NameTooShortError(Exception):
    pass


class MustContainAtSymbolError(Exception):
    pass

class InvalidDomainError(Exception):
    pass
correct = True
while True:
    email_input = input()
    name = ""
    for el in email_input:
        if el == "@":
            break
        name += el
    if len(name) <= 4:
        correct = False
        raise NameTooShortError("Name must be more than 4 characters")
    if not "@" in email_input:
        correct = False
        raise MustContainAtSymbolError("Email must contain @")
    domein = ""
    for i in range(len(email_input)):
        if email_input[i] == ".":
            for el in range(i, len(email_input[::-1])):
                domein += email_input[el]
    if domein not in (".com", ".bg", ".org", ".net"):
        correct = False
        raise InvalidDomainError("Domain must be one of the following: .com, .bg, .org, .net")

    if correct:
        print("Email is valid")
