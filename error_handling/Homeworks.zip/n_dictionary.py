numbers_dictionary = {}

while True:
    num_as_text = input()
    if num_as_text == "Search":
        break
    try:
        number_as_integer = int(input())
        numbers_dictionary[num_as_text] = number_as_integer
    except ValueError:
        print("The variable number must be an integer")

while True:
    searched_num_as_a_text = input()
    if searched_num_as_a_text == "Remove":
        break
    try:
        print(numbers_dictionary[searched_num_as_a_text])
    except KeyError:
        print("Number does not exist in dictionary")

while True:
    searched_num_as_a_text_remove = input()
    if searched_num_as_a_text_remove == "End":
        break
    try:
        del numbers_dictionary[searched_num_as_a_text_remove]
    except KeyError:
        print("Number does not exist in dictionary")

print(numbers_dictionary)
